export const baseApiUrl = "http://localhost:5000/api/"
export const baseUrl = "http://localhost:5000/"