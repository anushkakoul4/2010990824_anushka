import * as React from 'react'

export default class Home extends React.Component {
    render() {
        return (
            <div>
                <h1 className="title is-1">Home page</h1>
                <hr /> 
                Put something here.
            </div>
        )
    }
}